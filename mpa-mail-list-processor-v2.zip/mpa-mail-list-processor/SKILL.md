---
name: mpa-mail-list-processor
description: Clean and standardize raw customer mailing lists into BCC Bulk Mailer-ready CSV format with intelligent name/business parsing, international address flagging, and data validation. Keeps full addresses intact for BCC processing.
metadata:
  version: 2.0.0
  dependencies: python>=3.8, pandas>=2.0.0, usaddress>=0.5.10, openpyxl>=3.0.0
---

# MPA Mail List Processing Skill

## Overview
This Skill transforms messy customer-provided mailing lists into clean, standardized CSV files ready for import into BCC Bulk Mailer Professional/Business. It intelligently handles business names, personal names, or combinations of both, keeps full street addresses intact, and automatically flags international addresses for separate processing.

## When to Use This Skill
Use this Skill whenever:
- A customer provides a raw mailing list in Excel or CSV format
- You need to prepare data for BCC Bulk Mailer import
- Lists contain mix of businesses, individuals, or both
- You need to identify international addresses
- Address data needs cleaning or standardization
- You're setting up a new direct mail or EDDM campaign

## What This Skill Does

### 1. Input Handling
- Accepts Excel (.xlsx, .xls) or CSV files
- Automatically detects column headers and data structure
- Handles files with inconsistent formatting, encoding issues, or malformed data

### 2. Smart Name/Business Detection
The Skill intelligently determines what type of recipient each record is:

**Business Only:**
- Input: "Acme Corporation"
- Output: Company="Acme Corporation", FirstName=blank, LastName=blank

**Person Only:**
- Input: "John Smith"
- Output: FirstName="John", LastName="Smith", Company=blank

**Business + Person:**
- Input: Company="Acme Corp", Name="John Smith"
- Output: Company="Acme Corp", FirstName="John", LastName="Smith"

The Skill looks for business indicators like: LLC, Inc, Corp, Corporation, Company, Co., Ltd, LLP, etc.

### 3. Address Handling
- **Full Address Kept Intact**: Does NOT split into Address1/Address2
- **City/State/ZIP Extraction**: Pulls these from combined fields when needed
- **Example**: "123 Main St Apt 4B, Boston MA 02115" → Address="123 Main St Apt 4B", City="Boston", State="MA", ZIP="02115"
- **State Normalization**: Converts "Massachusetts" → "MA", "Fla" → "FL", etc.
- **ZIP Validation**: Validates 5-digit or ZIP+4 format

### 4. International Address Detection
- **Automatically Flags**: Records with non-US countries or international indicators
- **INTERNATIONAL Column**: Added to output (YES/NO)
- **Easy Filtering**: Sort/filter by this column in BCC to process separately
- **Detection**: Looks for country names, international postal codes, non-US state/provinces

### 5. Data Quality
- **Completeness Check**: Flags records missing required fields
- **Validation**: Ensures data meets BCC and USPS requirements  
- **Error Reporting**: Creates detailed report of issues found
- **No Deduplication**: BCC handles deduping after import

### 6. Output Generation
- Exports clean CSV in UTF-8 encoding without BOM
- Uses standardized BCC-compatible column headers
- Adds **OSEQ** field (Original Sequence number) for reference tracking
- Adds **INTERNATIONAL** flag for easy filtering
- Preserves all additional fields from source data
- Creates machine-readable filenames with date stamps

## Output Schema

### Standard Columns (BCC Bulk Mailer)
| Column | Description | Format | Required |
|--------|-------------|--------|----------|
| `OSEQ` | Original sequence number | Integer | Yes (MPA Standard) |
| `FirstName` | First name (if individual) | Text | Optional* |
| `LastName` | Last name (if individual) | Text | Optional* |
| `FullName` | Combined full name | Text | Optional* |
| `Company` | Business name | Text | Optional* |
| `Address` | **Complete street address (NOT split)** | Text | **Required** |
| `City` | City name | Text | **Required** |
| `State` | 2-letter USPS abbreviation | Text (2 chars) | **Required for US** |
| `ZIP` | 5-digit ZIP code | Text (5 digits) | **Required for US** |
| `ZIP4` | 4-digit ZIP extension | Text (4 digits) | Optional |
| `INTERNATIONAL` | International address flag | YES/NO | Yes (MPA Standard) |

*At minimum, either FullName OR FirstName/LastName OR Company must be present

### Preserved Columns
Any additional columns from source data (Email, Phone, Account ID, etc.) are automatically preserved

## Business Name Logic

### Detection Rules
The Skill uses intelligent pattern matching to determine if a name is a business:

**Business Indicators:**
- LLC, L.L.C., Inc, Incorporated, Corp, Corporation
- Company, Co., Ltd, Limited, LLP, P.C., P.A.
- Services, Solutions, Group, Associates, Partners
- No first name + last name pattern detected

**Examples:**

| Input | FirstName | LastName | FullName | Company |
|-------|-----------|----------|----------|---------|
| "ACME CORP" | - | - | - | Acme Corp |
| "John Smith" | John | Smith | John Smith | - |
| "Smith Enterprises LLC" | - | - | - | Smith Enterprises LLC |
| Company: "Acme", Name: "John Smith" | John | Smith | John Smith | Acme |
| "Dr. Jane Doe" | Jane | Doe | Dr. Jane Doe | - |
| "ABC Company Attn: Bob Jones" | Bob | Jones | Bob Jones | ABC Company |

## International Address Detection

### What Gets Flagged
Records are marked INTERNATIONAL=YES if they contain:

**Country Indicators:**
- Canada, Mexico, UK, United Kingdom, Germany, France, etc.
- Any country name (full list of 195+ countries checked)

**Postal Code Patterns:**
- Canadian: A1A 1A1
- UK: SW1A 1AA  
- Other non-US formats

**State/Province Non-US:**
- ON, BC, QC (Canadian provinces)
- Non-US state names

**Missing US Required Fields:**
- Has address but no valid US state
- Has address but no valid US ZIP

### Output Handling
```
OSEQ,FirstName,LastName,Company,Address,City,State,ZIP,INTERNATIONAL
1,John,Doe,,123 Main St,Boston,MA,02115,NO
2,Jane,Smith,,456 Oak Ave,Toronto,ON,M5H2N2,YES
3,,,Acme Ltd,789 High St,London,,,YES
```

Easy to filter in BCC or Excel: Sort by INTERNATIONAL column, process NO records through CASS/presort, handle YES records separately.

## Processing Steps

### Step 1: Load and Inspect
```python
# The Skill will:
# 1. Load the source file (Excel or CSV)
# 2. Display first few rows for verification
# 3. Identify which columns contain address/name data
# 4. Report initial record count
```

### Step 2: Parse and Clean
```python
# For each record:
# 1. Assign OSEQ (original sequence number)
# 2. Detect if Business, Person, or Both
# 3. Extract City, State, ZIP from combined address if needed
# 4. Keep FULL street address intact (no Address1/Address2 split)
# 5. Check for international indicators
# 6. Normalize state to USPS abbreviation (if US)
# 7. Validate and format ZIP codes (if US)
# 8. Clean whitespace and special characters
# 9. Apply title case to names and addresses
# 10. Flag as INTERNATIONAL=YES or NO
```

### Step 3: Validate and Report
```python
# Check each record for:
# - Missing required fields (Address, City)
# - For US records: Missing State or ZIP
# - For International: Proper flagging
# - Invalid data formats
# 
# Generate validation report showing:
# - Total records processed
# - US vs International breakdown
# - Records with errors/warnings
# - Specific issues by record number (OSEQ)
```

### Step 4: Export
```python
# Create output file:
# - Filename: Job_MailingList_YYYY-MM-DD_HHMM.csv
# - Format: UTF-8 CSV without BOM
# - Headers: BCC-standard column names
# - Order: OSEQ, FirstName, LastName, FullName, Company, Address, City, State, ZIP, ZIP4, INTERNATIONAL, [additional fields]
# - Note: NO deduplication (BCC handles that)
```

## Example Transformations

### Example 1: Business Only
**Input:**
```
Name: ACME CORPORATION
Address: 123 MAIN STREET SUITE 400, BOSTON MASSACHUSETTS 02115
```

**Output:**
```
OSEQ: 1
Company: Acme Corporation
Address: 123 Main Street Suite 400
City: Boston
State: MA
ZIP: 02115
INTERNATIONAL: NO
```

### Example 2: Person Only
**Input:**
```
Name: JOHN SMITH
Address: 456 OAK AVE APT 3B, SPRINGFIELD IL 62704
```

**Output:**
```
OSEQ: 2
FirstName: John
LastName: Smith
FullName: John Smith
Address: 456 Oak Ave Apt 3B
City: Springfield
State: IL
ZIP: 62704
INTERNATIONAL: NO
```

### Example 3: Business + Person
**Input:**
```
Company: TECH SOLUTIONS LLC
Contact: Jane Doe
Address: 789 ELM ST, LAKELAND FL 33801
```

**Output:**
```
OSEQ: 3
FirstName: Jane
LastName: Doe
FullName: Jane Doe
Company: Tech Solutions LLC
Address: 789 Elm St
City: Lakeland
State: FL
ZIP: 33801
INTERNATIONAL: NO
```

### Example 4: International Address
**Input:**
```
Name: Robert Brown
Address: 100 King St W, Toronto ON M5H 1A1, Canada
```

**Output:**
```
OSEQ: 4
FirstName: Robert
LastName: Brown
FullName: Robert Brown
Address: 100 King St W
City: Toronto
State: ON
ZIP: M5H 1A1
INTERNATIONAL: YES
```

## Integration with BCC Bulk Mailer

After running this Skill:

### For US Addresses (INTERNATIONAL=NO)
1. **Filter/Sort** output CSV to show only INTERNATIONAL=NO records
2. **Import to BCC**: File > Import > Select the filtered CSV
3. **Field Mapping**: BCC will auto-detect headers
4. **Run CASS**: Process > CASS Certification
5. **Run NCOA**: Process > NCOA (if required)
6. **Presort**: Process > Presort for postal discounts

### For International Addresses (INTERNATIONAL=YES)
1. **Filter** output CSV to show only INTERNATIONAL=YES records
2. **Process separately** - international mail has different requirements
3. **Use appropriate carrier** (DHL, FedEx, USPS International, etc.)
4. **No CASS/NCOA** - these are US-only processes

## Technical Notes

### No Deduplication
- Skill does NOT remove duplicates
- BCC Bulk Mailer has superior deduplication tools
- Better to dedupe after CASS when addresses are standardized

### Dependencies
- `pandas` - Data manipulation and CSV/Excel handling
- `usaddress` - USPS address parsing library (for City/State/ZIP extraction only)
- `openpyxl` - Excel file reading
- `re` - Regular expressions for validation and pattern matching

### Performance
- Processes ~1,000 records per second on typical lists
- Memory-efficient streaming for large files (100K+ records)

## Version History
- **2.0.0** - No address splitting, no deduplication, business name intelligence, international flagging
- **1.0.0** - Initial release with address parsing and validation
