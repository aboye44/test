#!/usr/bin/env python3
"""
MPA Mail List Processor v2.0
- Keeps full addresses intact (no Address1/Address2 split)
- Intelligent business name detection
- International address flagging
- No deduplication (handled in BCC)
"""

import pandas as pd
import re
import usaddress
from datetime import datetime
from pathlib import Path
import sys
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# USPS State Abbreviations
USPS_STATES = {
    'ALABAMA': 'AL', 'ALASKA': 'AK', 'ARIZONA': 'AZ', 'ARKANSAS': 'AR',
    'CALIFORNIA': 'CA', 'COLORADO': 'CO', 'CONNECTICUT': 'CT', 'DELAWARE': 'DE',
    'FLORIDA': 'FL', 'GEORGIA': 'GA', 'HAWAII': 'HI', 'IDAHO': 'ID',
    'ILLINOIS': 'IL', 'INDIANA': 'IN', 'IOWA': 'IA', 'KANSAS': 'KS',
    'KENTUCKY': 'KY', 'LOUISIANA': 'LA', 'MAINE': 'ME', 'MARYLAND': 'MD',
    'MASSACHUSETTS': 'MA', 'MICHIGAN': 'MI', 'MINNESOTA': 'MN', 'MISSISSIPPI': 'MS',
    'MISSOURI': 'MO', 'MONTANA': 'MT', 'NEBRASKA': 'NE', 'NEVADA': 'NV',
    'NEW HAMPSHIRE': 'NH', 'NEW JERSEY': 'NJ', 'NEW MEXICO': 'NM', 'NEW YORK': 'NY',
    'NORTH CAROLINA': 'NC', 'NORTH DAKOTA': 'ND', 'OHIO': 'OH', 'OKLAHOMA': 'OK',
    'OREGON': 'OR', 'PENNSYLVANIA': 'PA', 'RHODE ISLAND': 'RI', 'SOUTH CAROLINA': 'SC',
    'SOUTH DAKOTA': 'SD', 'TENNESSEE': 'TN', 'TEXAS': 'TX', 'UTAH': 'UT',
    'VERMONT': 'VT', 'VIRGINIA': 'VA', 'WASHINGTON': 'WA', 'WEST VIRGINIA': 'WV',
    'WISCONSIN': 'WI', 'WYOMING': 'WY', 'DISTRICT OF COLUMBIA': 'DC',
    'PUERTO RICO': 'PR', 'VIRGIN ISLANDS': 'VI', 'GUAM': 'GU'
}

STATE_VARIATIONS = {
    'ALA': 'AL', 'ALAS': 'AK', 'ARIZ': 'AZ', 'ARK': 'AR',
    'CALIF': 'CA', 'CAL': 'CA', 'COLO': 'CO', 'CONN': 'CT',
    'DEL': 'DE', 'FLA': 'FL', 'FLOR': 'FL', 'GA.': 'GA',
    'ILL': 'IL', 'IND': 'IN', 'KANS': 'KS', 'KAN': 'KS',
    'KY.': 'KY', 'LA.': 'LA', 'MASS': 'MA', 'MICH': 'MI',
    'MINN': 'MN', 'MISS': 'MS', 'MO.': 'MO', 'MONT': 'MT',
    'NEBR': 'NE', 'NEB': 'NE', 'NEV': 'NV', 'N.H.': 'NH',
    'N.J.': 'NJ', 'N.M.': 'NM', 'N.Y.': 'NY', 'N.C.': 'NC',
    'N.D.': 'ND', 'OKLA': 'OK', 'ORE': 'OR', 'PENN': 'PA',
    'PA.': 'PA', 'R.I.': 'RI', 'S.C.': 'SC', 'S.D.': 'SD',
    'TENN': 'TN', 'TEX': 'TX', 'VT.': 'VT', 'VA.': 'VA',
    'WASH': 'WA', 'W.VA.': 'WV', 'WIS': 'WI', 'WISC': 'WI',
    'WYO': 'WY', 'D.C.': 'DC'
}

# Business name indicators
BUSINESS_INDICATORS = [
    r'\bLLC\b', r'\bL\.L\.C\.?\b', r'\bINC\.?\b', r'\bINCORPORATED\b',
    r'\bCORP\.?\b', r'\bCORPORATION\b', r'\bCOMPANY\b', r'\bCO\.?\b',
    r'\bLTD\.?\b', r'\bLIMITED\b', r'\bLLP\b', r'\bP\.C\.?\b', r'\bP\.A\.?\b',
    r'\bSERVICES\b', r'\bSOLUTIONS\b', r'\bGROUP\b', r'\bASSOCIATES\b',
    r'\bPARTNERS\b', r'\bENTERPRISES\b', r'\bINDUSTRIES\b'
]

# Common countries (partial list - expand as needed)
COUNTRIES = [
    'CANADA', 'MEXICO', 'UNITED KINGDOM', 'UK', 'ENGLAND', 'SCOTLAND', 'WALES',
    'IRELAND', 'GERMANY', 'FRANCE', 'SPAIN', 'ITALY', 'NETHERLANDS', 'BELGIUM',
    'SWITZERLAND', 'AUSTRIA', 'SWEDEN', 'NORWAY', 'DENMARK', 'FINLAND',
    'POLAND', 'CZECH REPUBLIC', 'PORTUGAL', 'GREECE', 'AUSTRALIA', 'NEW ZEALAND',
    'JAPAN', 'CHINA', 'SOUTH KOREA', 'INDIA', 'BRAZIL', 'ARGENTINA', 'CHILE'
]

# Canadian provinces
CANADIAN_PROVINCES = ['ON', 'BC', 'QC', 'AB', 'MB', 'SK', 'NS', 'NB', 'NL', 'PE', 'NT', 'YT', 'NU']


class MailListProcessor:
    def __init__(self):
        self.errors = []
        self.warnings = []
        self.stats = {
            'total_records': 0,
            'valid_records': 0,
            'error_records': 0,
            'us_addresses': 0,
            'international_addresses': 0,
            'business_only': 0,
            'person_only': 0,
            'business_and_person': 0
        }
    
    def is_business_name(self, name: str) -> bool:
        """Detect if a name is likely a business"""
        if pd.isna(name) or not name:
            return False
        
        name_upper = str(name).upper()
        
        # Check for business indicators
        for pattern in BUSINESS_INDICATORS:
            if re.search(pattern, name_upper):
                return True
        
        return False
    
    def is_international(self, address: str, city: str, state: str, zip_code: str) -> bool:
        """Detect if address is international (non-US)"""
        
        # Check for country names in address or city
        combined = f"{address} {city}".upper() if address or city else ""
        for country in COUNTRIES:
            if country in combined:
                return True
        
        # Check for Canadian provinces
        if state and state.upper() in CANADIAN_PROVINCES:
            return True
        
        # Check for non-US state (if state present but not valid US)
        if state:
            state_upper = state.upper().strip()
            if len(state_upper) == 2:
                if state_upper not in USPS_STATES.values():
                    # Could be international province code
                    return True
        
        # Check for international postal code patterns
        if zip_code:
            zip_str = str(zip_code).strip().upper()
            # Canadian postal code: A1A 1A1 or A1A1A1
            if re.match(r'^[A-Z]\d[A-Z]\s?\d[A-Z]\d$', zip_str):
                return True
            # UK postal code patterns
            if re.match(r'^[A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2}$', zip_str):
                return True
        
        # If has address but missing US state or ZIP, likely international
        if address and not state:
            return True
        if address and state and not zip_code:
            # Has address and state but no ZIP - could be international
            state_upper = state.upper().strip() if state else ""
            if len(state_upper) == 2 and state_upper not in USPS_STATES.values():
                return True
        
        return False
    
    def normalize_state(self, state: str) -> Optional[str]:
        """Convert state name/variation to USPS 2-letter abbreviation"""
        if pd.isna(state) or not state:
            return None
        
        state = str(state).strip().upper()
        state = re.sub(r'\.', '', state)
        state = re.sub(r'\s+', ' ', state)
        
        if len(state) == 2 and state in USPS_STATES.values():
            return state
        
        if state in STATE_VARIATIONS:
            return STATE_VARIATIONS[state]
        
        if state in USPS_STATES:
            return USPS_STATES[state]
        
        return None
    
    def validate_zip(self, zip_code: str) -> Tuple[Optional[str], Optional[str]]:
        """Validate and split ZIP code"""
        if pd.isna(zip_code) or not zip_code:
            return None, None
        
        zip_str = str(zip_code).strip()
        zip_str = re.sub(r'[^\d\-]', '', zip_str)
        
        match = re.match(r'^(\d{5})(?:-?(\d{4}))?$', zip_str)
        
        if match:
            return match.group(1), match.group(2) if match.group(2) else None
        
        return None, None
    
    def extract_address_parts(self, address_str: str) -> Dict[str, str]:
        """Extract City, State, ZIP from combined address while keeping full street address"""
        if pd.isna(address_str) or not address_str:
            return {}
        
        result = {'Address': None, 'City': None, 'State': None, 'ZIP': None, 'ZIP4': None}
        
        address_str = str(address_str).strip()
        
        try:
            parsed, _ = usaddress.tag(address_str)
            
            # Keep the FULL street address (everything before city)
            street_parts = []
            for field in ['AddressNumber', 'StreetNamePreDirectional', 'StreetName', 
                          'StreetNamePostType', 'StreetNamePostDirectional',
                          'OccupancyType', 'OccupancyIdentifier', 
                          'USPSBoxType', 'USPSBoxID']:
                if field in parsed:
                    street_parts.append(parsed[field])
            
            if street_parts:
                result['Address'] = ' '.join(street_parts)
            
            result['City'] = parsed.get('PlaceName')
            
            if 'StateName' in parsed:
                result['State'] = self.normalize_state(parsed['StateName'])
            
            if 'ZipCode' in parsed:
                zip5, zip4 = self.validate_zip(parsed['ZipCode'])
                result['ZIP'] = zip5
                result['ZIP4'] = zip4
                
        except:
            # Fallback: try regex extraction
            # Extract ZIP from end
            zip_match = re.search(r'(\d{5})(?:-(\d{4}))?$', address_str)
            if zip_match:
                result['ZIP'] = zip_match.group(1)
                result['ZIP4'] = zip_match.group(2)
                address_str = address_str[:zip_match.start()].strip()
            
            # Extract state (2 letters before ZIP or at end)
            state_match = re.search(r'\b([A-Z]{2})\s*$', address_str)
            if state_match:
                result['State'] = state_match.group(1)
                address_str = address_str[:state_match.start()].strip()
            
            # Split by comma - last part is city
            parts = [p.strip() for p in address_str.split(',')]
            if len(parts) >= 2:
                result['City'] = parts[-1]
                result['Address'] = ', '.join(parts[:-1])
            elif len(parts) == 1:
                result['Address'] = parts[0]
        
        return result
    
    def split_name(self, full_name: str) -> Tuple[Optional[str], Optional[str]]:
        """Split full name into first and last"""
        if pd.isna(full_name) or not full_name:
            return None, None
        
        name = str(full_name).strip()
        name = re.sub(r'\b(Jr\.?|Sr\.?|II|III|IV)\b', '', name, flags=re.IGNORECASE).strip()
        
        parts = name.split()
        
        if len(parts) == 0:
            return None, None
        elif len(parts) == 1:
            return parts[0], None
        elif len(parts) == 2:
            return parts[0], parts[1]
        else:
            return parts[0], ' '.join(parts[1:])
    
    def title_case(self, text: str) -> str:
        """Apply proper title case"""
        if pd.isna(text) or not text:
            return text
        
        text = str(text).strip()
        
        if text.isupper() or text.islower():
            words = []
            for word in text.split():
                if word.upper() in ['PO', 'P.O.', 'P.O']:
                    words.append('PO')
                elif word.upper() in ['NW', 'NE', 'SW', 'SE', 'LLC', 'INC', 'CO', 'CORP', 'LTD', 'LLP']:
                    words.append(word.upper())
                else:
                    words.append(word.capitalize())
            return ' '.join(words)
        
        return text
    
    def clean_text(self, text: str) -> str:
        """Clean text of problematic characters"""
        if pd.isna(text) or not text:
            return text
        
        text = str(text)
        text = re.sub(r'[^\x20-\x7E]', '', text)
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()
        
        return text if text else None
    
    def detect_columns(self, df: pd.DataFrame) -> Dict[str, str]:
        """Auto-detect column mappings"""
        patterns = {
            'name': r'(full.?name|name|recipient|addressee|customer|contact)',
            'first': r'(first.?name|fname|given.?name)',
            'last': r'(last.?name|lname|surname|family.?name)',
            'company': r'(company|business|organization|org)',
            'address': r'(address|addr|street|mailing)',
            'city': r'(city|town|municipality)',
            'state': r'(state|st|province)',
            'zip': r'(zip|postal|postcode)',
            'country': r'(country)',
        }
        
        col_map = {}
        cols_lower = {col.lower(): col for col in df.columns}
        
        for key, pattern in patterns.items():
            for col_lower, col_original in cols_lower.items():
                if re.search(pattern, col_lower, re.IGNORECASE):
                    col_map[key] = col_original
                    break
        
        return col_map
    
    def load_file(self, filepath: str) -> pd.DataFrame:
        """Load Excel or CSV file"""
        path = Path(filepath)
        
        if path.suffix.lower() in ['.xlsx', '.xls']:
            df = pd.read_excel(filepath)
        elif path.suffix.lower() == '.csv':
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    df = pd.read_csv(filepath, encoding=encoding)
                    break
                except:
                    continue
        else:
            raise ValueError(f"Unsupported file type: {path.suffix}")
        
        df.columns = df.columns.str.strip()
        self.stats['total_records'] = len(df)
        return df
    
    def process_list(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Main processing function"""
        
        df['OSEQ'] = range(1, len(df) + 1)
        col_map = self.detect_columns(df)
        
        output_records = []
        error_records = []
        
        for idx, row in df.iterrows():
            oseq = row['OSEQ']
            record = {'OSEQ': oseq}
            errors_this_row = []
            
            try:
                # Handle names and business detection
                has_separate_company = False
                
                # Check for separate company column
                if 'company' in col_map and col_map['company'] in df.columns:
                    company_raw = self.clean_text(row.get(col_map['company']))
                    if company_raw:
                        record['Company'] = self.title_case(company_raw)
                        has_separate_company = True
                
                # Handle name fields
                if 'name' in col_map and col_map['name'] in df.columns:
                    full_name = self.clean_text(row.get(col_map['name']))
                    if full_name:
                        # Check if this is a business name
                        if not has_separate_company and self.is_business_name(full_name):
                            # It's a business name
                            record['Company'] = self.title_case(full_name)
                            self.stats['business_only'] += 1
                        else:
                            # It's a person name
                            record['FullName'] = self.title_case(full_name)
                            first, last = self.split_name(full_name)
                            record['FirstName'] = self.title_case(first) if first else None
                            record['LastName'] = self.title_case(last) if last else None
                            
                            if has_separate_company:
                                self.stats['business_and_person'] += 1
                            else:
                                self.stats['person_only'] += 1
                
                # Handle separate first/last name columns
                if 'first' in col_map and col_map['first'] in df.columns:
                    record['FirstName'] = self.title_case(self.clean_text(row.get(col_map['first'])))
                
                if 'last' in col_map and col_map['last'] in df.columns:
                    record['LastName'] = self.title_case(self.clean_text(row.get(col_map['last'])))
                
                # Build FullName if not present
                if not record.get('FullName') and (record.get('FirstName') or record.get('LastName')):
                    parts = [p for p in [record.get('FirstName'), record.get('LastName')] if p]
                    record['FullName'] = ' '.join(parts) if parts else None
                
                # Handle address
                address_parsed = False
                if 'address' in col_map and col_map['address'] in df.columns:
                    addr = row.get(col_map['address'])
                    if pd.notna(addr) and str(addr).strip():
                        parsed = self.extract_address_parts(str(addr))
                        if parsed.get('Address'):
                            record.update(parsed)
                            address_parsed = True
                
                # If not parsed, look for separate fields
                if not address_parsed:
                    if 'address' in col_map:
                        record['Address'] = self.title_case(self.clean_text(row.get(col_map['address'])))
                    if 'city' in col_map:
                        record['City'] = self.title_case(self.clean_text(row.get(col_map['city'])))
                    if 'state' in col_map:
                        state_raw = self.clean_text(row.get(col_map['state']))
                        record['State'] = self.normalize_state(state_raw)
                    if 'zip' in col_map:
                        zip5, zip4 = self.validate_zip(row.get(col_map['zip']))
                        record['ZIP'] = zip5
                        record['ZIP4'] = zip4
                
                # Check for international
                is_intl = self.is_international(
                    record.get('Address'),
                    record.get('City'),
                    record.get('State'),
                    record.get('ZIP')
                )
                
                record['INTERNATIONAL'] = 'YES' if is_intl else 'NO'
                
                if is_intl:
                    self.stats['international_addresses'] += 1
                else:
                    self.stats['us_addresses'] += 1
                
                # Validation
                if not record.get('Address'):
                    errors_this_row.append("Missing Address")
                
                if not record.get('City'):
                    errors_this_row.append("Missing City")
                
                # For US addresses, require State and ZIP
                if not is_intl:
                    if not record.get('State'):
                        errors_this_row.append("Missing State (US address)")
                    if not record.get('ZIP'):
                        errors_this_row.append("Missing ZIP (US address)")
                
                # Check name or company present
                if not any([record.get('FullName'), record.get('FirstName'), 
                           record.get('LastName'), record.get('Company')]):
                    errors_this_row.append("Missing recipient name/company")
                
                # Preserve extra fields
                for col in df.columns:
                    if col not in col_map.values() and col != 'OSEQ':
                        record[col] = row[col]
                
                # Categorize
                if errors_this_row:
                    record['_errors'] = '; '.join(errors_this_row)
                    error_records.append(record)
                    self.stats['error_records'] += 1
                    self.errors.append(f"OSEQ {oseq}: {', '.join(errors_this_row)}")
                else:
                    output_records.append(record)
                    self.stats['valid_records'] += 1
                    
            except Exception as e:
                error_msg = f"OSEQ {oseq}: Processing error - {str(e)}"
                self.errors.append(error_msg)
                record['_errors'] = str(e)
                error_records.append(record)
                self.stats['error_records'] += 1
        
        # Create dataframes
        output_df = pd.DataFrame(output_records) if output_records else pd.DataFrame()
        error_df = pd.DataFrame(error_records) if error_records else pd.DataFrame()
        
        # Order columns
        std_cols = ['OSEQ', 'FirstName', 'LastName', 'FullName', 'Company', 
                    'Address', 'City', 'State', 'ZIP', 'ZIP4', 'INTERNATIONAL']
        
        if len(output_df) > 0:
            extra_cols = [c for c in output_df.columns if c not in std_cols]
            final_cols = [c for c in std_cols if c in output_df.columns] + extra_cols
            output_df = output_df[final_cols]
        
        return output_df, error_df
    
    def generate_report(self) -> str:
        """Generate validation report"""
        report = []
        report.append("=" * 70)
        report.append("MPA MAIL LIST PROCESSING REPORT")
        report.append("=" * 70)
        report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        report.append("SUMMARY STATISTICS")
        report.append("-" * 70)
        report.append(f"Total records processed:    {self.stats['total_records']:,}")
        report.append(f"Valid records:              {self.stats['valid_records']:,}")
        report.append(f"Error records:              {self.stats['error_records']:,}")
        report.append(f"")
        report.append(f"US addresses:               {self.stats['us_addresses']:,}")
        report.append(f"International addresses:    {self.stats['international_addresses']:,}")
        report.append(f"")
        report.append(f"Business only:              {self.stats['business_only']:,}")
        report.append(f"Person only:                {self.stats['person_only']:,}")
        report.append(f"Business + Person:          {self.stats['business_and_person']:,}")
        report.append("")
        
        if self.errors:
            report.append("ERRORS")
            report.append("-" * 70)
            for error in self.errors[:100]:
                report.append(error)
            if len(self.errors) > 100:
                report.append(f"... and {len(self.errors) - 100} more errors")
            report.append("")
        
        report.append("=" * 70)
        report.append("NEXT STEPS")
        report.append("-" * 70)
        report.append("1. Review error records file (if generated)")
        report.append("2. Filter by INTERNATIONAL column:")
        report.append("   - INTERNATIONAL=NO → Import to BCC for CASS/presort")
        report.append("   - INTERNATIONAL=YES → Process separately for international mail")
        report.append("3. Import US records into BCC Bulk Mailer")
        report.append("4. Run CASS certification (US only)")
        report.append("5. Run NCOA if required (US only)")
        report.append("6. Process presort for postal discounts")
        report.append("=" * 70)
        
        return '\n'.join(report)


def main():
    """Main entry point"""
    if len(sys.argv) < 2:
        print("Usage: python process_mail_list.py <input_file>")
        sys.exit(1)
    
    input_file = sys.argv[1]
    
    print("MPA Mail List Processor v2.0")
    print("=" * 70)
    print(f"Input file: {input_file}")
    print("")
    
    processor = MailListProcessor()
    
    try:
        print("Loading file...")
        df = processor.load_file(input_file)
        print(f"Loaded {len(df):,} records")
        print("")
        
        print("Sample of input data (first 3 rows):")
        print(df.head(3).to_string())
        print("")
        
        print("Processing records...")
        clean_df, error_df = processor.process_list(df)
        print(f"Processing complete: {len(clean_df):,} valid, {len(error_df):,} errors")
        print(f"US: {processor.stats['us_addresses']:,}, International: {processor.stats['international_addresses']:,}")
        print("")
        
        timestamp = datetime.now().strftime('%Y-%m-%d_%H%M')
        base_name = f"Job_MailingList_{timestamp}"
        
        output_file = f"{base_name}.csv"
        report_file = f"{base_name}_Report.txt"
        error_file = f"{base_name}_Errors.csv" if len(error_df) > 0 else None
        
        print(f"Saving clean records to: {output_file}")
        clean_df.to_csv(output_file, index=False, encoding='utf-8')
        
        if error_file:
            print(f"Saving error records to: {error_file}")
            error_df.to_csv(error_file, index=False, encoding='utf-8')
        
        print(f"Generating report: {report_file}")
        report = processor.generate_report()
        with open(report_file, 'w') as f:
            f.write(report)
        
        print("")
        print(report)
        
        print("")
        print("Processing complete! Files created in current directory.")
        
    except Exception as e:
        print(f"ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
