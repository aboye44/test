---
name: cfl-direct-mail-pricing
description: Comprehensive Central Florida direct mail pricing engine with real market data, competitor intelligence, equipment cost structures, and USPS rates. Provides accurate quotes for postcards, letters, and direct mail campaigns in the Tampa/Lakeland/Orlando corridor with competitive positioning analysis (25th-90th percentile). Use when user requests direct mail pricing, needs competitive benchmarking, or wants to optimize mail campaign specifications.
---

# Central Florida Direct Mail Pricing Engine

## Purpose
Provide **highly accurate** pricing estimates for direct mail projects in the Tampa/Lakeland/Orlando corridor based on real competitive market data, actual equipment costs, and current material pricing. This skill generates quotes that are defensible, profitable, and market-competitive.

## When to Use This Skill
- User requests pricing for postcards, letters, or direct mail campaigns
- User asks about direct mail costs or competitive positioning
- User needs to compare digital vs. offset economics
- User wants to optimize specifications for cost efficiency

## Core Pricing Philosophy
Direct mail pricing in Central Florida follows a **3-4 line item structure**:
1. **Printing** (paper + production)
2. **Inkjet Addressing** (variable data addressing)
3. **Data Processing & Mail Prep** (CASS, presort, bundling, traying, manifesting)
4. **Postage** (typically pass-through, no markup)

---

## MARKET DATA - CENTRAL FLORIDA (50th Percentile/Median Rates)

### 6x11 Postcards (4/4 Full Color, 100# Gloss Cover Stock)

**Per-Piece Pricing by Line Item (50th Percentile):**

| Line Item | Rate Range | Median |
|-----------|------------|--------|
| **Printing** | $0.17-$0.23/pc | $0.20/pc |
| **Inkjet Addressing** | $0.025-$0.035/pc | $0.030/pc |
| **CASS/Data Processing** | $0.020-$0.030/pc | $0.025/pc |
| **Presort & Mail Prep** | $0.055-$0.075/pc | $0.065/pc |
| **Services Subtotal** | $0.27-$0.37/pc | **$0.32/pc** |
| **First-Class Postage** | $0.58-$0.60/pc | $0.594/pc |
| **TOTAL ALL-IN** | $0.88-$0.94/pc | **$0.914/pc** |

**Volume: 6,033 pieces**
- **50th Percentile Total: $5,513** ($0.914/pc)

### Competitive Positioning by Percentile

| Percentile | All-In Price Range | Market Position | Who Quotes Here |
|------------|-------------------|-----------------|-----------------|
| **25th (Low)** | $0.82-$0.87/pc | Below median, competitive | Online services, trade printers |
| **50th (Median)** | $0.88-$0.94/pc | **Market-rate, defendable** | Independent mail houses, balanced shops |
| **75th (High)** | $0.95-$1.05/pc | Premium positioning | Franchise shops (Allegra, Minuteman, Sir Speedy) |
| **90th (Premium)** | $1.05-$1.20/pc | Premium/rush service | Rush jobs, premium features, consultative service |

### Actual Competitor Quotes (6,033 6x11 postcards, 4/4, 100# gloss, First-Class presorted):

**Franchise Operations:**
- Allegra/Minuteman/Sir Speedy: **$5,800** ($0.96/pc)
  - Single line: "Full Color, 100# Gloss, Printing, Addressing, CASS, Presort, First-Class Mail"

**Independent Mail Houses:**
- Tampa Bay mail houses: **$5,530** ($0.92/pc)
  - Format: Print $1,200 + Address/Data/Prep $750 + Postage $3,580

**Online Services:**
- 48HourPrint + Click2Mail: **$4,670** ($0.77/pc)
  - Print & Ship: $850 + Upload to Click2Mail: $240 + Postage: $3,580
  - *Customer coordinates two vendors*

---

## EQUIPMENT COST STRUCTURES

### Xerox Iridesse Production Press
**Optimal Use Cases:**
- Premium color postcards with specialty effects (metallic, clear, white)
- Short-to-medium runs: 50-5,000 pieces
- High-end booklet covers requiring 6-color capabilities
- Jobs requiring premium substrates (synthetic, heavy cover stocks up to 400gsm)

**Cost Structure:**
- **Click cost (CMYK):** $0.08-$0.12/impression (simplex, letter-size equivalent)
- **Click cost (CMYK + specialty color):** +$0.03-$0.05/impression for Gold/Silver/White/Clear
- **Paper handling:** Stocks from 60# text to 400gsm cover
- **Production speed:** 120 ppm (letter simplex), ~80-100 ppm on heavy cover
- **Makeready time:** 15-30 minutes depending on stock/settings
- **Finishing:** ALL OFFLINE - must account for handling and transition time

**6x11 Postcard Economics (Iridesse):**
- Printing cost: ~$0.10-$0.14/piece (CMYK, 100# gloss cover)
- Paper cost: ~$0.03-$0.05/piece (100# gloss cover)
- **Total printing cost:** $0.13-$0.19/piece

**When to use Iridesse:**
- Quantities under 5,000 where digital is competitive
- Premium jobs justifying specialty effects
- Fast turnaround (no offset makeready penalty)
- Variable data requirements

### Xerox Nuvera High-Volume B&W
**Optimal Use Cases:**
- High-volume black & white production (manuals, books, transactional)
- Long-run monochrome direct mail (1,000-50,000+)
- Booklet interiors (paired with Iridesse covers)

**Cost Structure:**
- **Click cost (B&W):** $0.01-$0.015/impression
- **Production speed:** 100-120 ppm depending on configuration
- **Optimal run length:** 1,000+ pieces where speed advantage pays off
- **Finishing:** ALL OFFLINE

**When to use Nuvera:**
- B&W booklet interiors
- Long-run simplex/duplex letters for direct mail
- Jobs where monochrome is acceptable and volume is high

### Offset Printing (40" Press)
**Cost Structure:**
- **Makeready cost:** $150-$250 (plates, setup, wash-up)
- **Press time:** $150-$200/hour
- **Click equivalent:** Effectively $0.03-$0.06/piece on long runs (5,000+)

**Breakeven vs. Digital:**
- 6x11 postcards: ~5,000-7,500 pieces (offset becomes cheaper)
- 8.5x11 flats: ~3,000-5,000 pieces

**When to recommend offset:**
- Quantities above 7,500 for 6x11 postcards
- Critical Pantone color matching requirements
- Specialty substrates digital can't handle
- Budget-conscious clients on long runs

---

## MATERIAL COSTS (Central Florida Market, Current Pricing)

### Paper Stock - Common Direct Mail Substrates

**Cover Stocks (Postcards):**
- 80# Gloss Cover: $0.025-$0.030/sheet (19x13, 8-up 6x11)
- 100# Gloss Cover: $0.030-$0.038/sheet (19x13, 8-up 6x11)
- 100# Matte Cover: $0.032-$0.040/sheet
- 130# Gloss Cover: $0.042-$0.050/sheet
- **Synthetic stocks:** Add $0.08-$0.15/piece

**Per-piece calculation (6x11 postcard from 19x13 sheet, 8-up):**
- 100# Gloss Cover: ~$0.034/sheet ÷ 8 = **$0.00425/piece** (raw stock)
- Add 15% for waste/spoilage = **$0.049/piece** (actual cost)

**Text Stocks (Letters, Booklet Interiors):**
- 60# Offset Text: $0.015-$0.020/sheet (letter size)
- 70# Text: $0.018-$0.024/sheet
- 80# Text: $0.022-$0.028/sheet

### Inkjet Addressing Supplies
- Inkjet cartridge cost (amortized): $0.008-$0.012/piece
- Labor for loading/setup: $25/hour shop rate

### Bindery Supplies
- Stitching wire (saddle-stitch booklets): $0.003-$0.005/book
- Perfect binding glue: $0.08-$0.12/book
- Folding: typically absorbed into labor

---

## USPS POSTAGE RATES (2025 Current)

### First-Class Mail Automation Rates (Presorted)

**Letters (up to 1 oz):**
- 5-Digit automation: $0.551/piece
- 3-Digit automation: $0.566/piece
- AADC automation: $0.581/piece
- Mixed AADC: $0.596/piece
- **Blended average (typical list):** $0.573/piece

**Flats (up to 1 oz):**
- 5-Digit automation: $0.873/piece
- 3-Digit automation: $0.898/piece
- AADC automation: $0.923/piece
- Mixed AADC: $0.948/piece
- **Blended average:** $0.910/piece

**Postcards (6x11 or smaller):**
- 5-Digit automation: $0.568/piece
- 3-Digit automation: $0.583/piece
- AADC automation: $0.598/piece
- Mixed AADC: $0.613/piece
- **Blended average:** $0.594/piece

### Marketing Mail (Standard) Automation Rates

**Letters:**
- High Density Plus (5-Digit): $0.285/piece
- Basic (AADC): $0.365/piece
- **Blended average:** $0.325/piece

**Flats:**
- High Density Plus: $0.435/piece
- Basic: $0.545/piece
- **Blended average:** $0.490/piece

**Postcards:**
- High Density Plus: $0.275/piece
- Basic: $0.355/piece
- **Blended average:** $0.315/piece

**IMPORTANT:** Marketing Mail requires minimum 200-piece mailing or meet other criteria.

---

## LABOR & HANDLING COSTS

### Inkjet Addressing
- **Setup time:** 20-30 minutes (file prep, test run)
- **Run time:** 5,000-8,000 pieces/hour (depending on equipment)
- **Labor rate:** $25/hour (loaded)
- **Effective labor cost:** $0.003-$0.005/piece
- **Total addressing cost (including ink):** $0.025-$0.035/piece

### Data Processing & CASS Certification
- **CASS software/service fee:** $75-$150 flat fee OR $0.015-$0.025/piece
- **List hygiene/deduplication:** $0.005-$0.010/piece
- **Setup labor:** 30-60 minutes at $25/hour
- **Typical bundled rate:** $0.025/piece (for CASS + basic processing)

### Presort, Bundling, Traying, Manifesting
- **Labor time:** 250-400 pieces/hour (depending on mail class complexity)
- **Labor rate:** $25/hour
- **Effective labor:** $0.063-$0.100/piece
- **USPS manifest prep:** Absorbed into labor
- **Typical market rate:** $0.065/piece

### Offline Finishing (Cutting, Trimming, Stacking)
- **Cutting to size:** $0.005-$0.010/piece (large format cutter)
- **Quality control/stacking:** $0.003-$0.005/piece
- **Transition time between press and bindery:** 15-30 minutes setup

---

## PRICING CALCULATION METHODOLOGY

### Step 1: Determine Equipment & Production Method
**Decision tree:**
1. **Quantity < 2,500 → Digital (Iridesse for color, Nuvera for B&W)**
2. **Quantity 2,500-7,500 → Evaluate digital vs. offset (usually digital)**
3. **Quantity > 7,500 → Offset typically more economical**
4. **Specialty requirements (metallic, variable data, fast turn) → Iridesse**

### Step 2: Calculate Printing Cost
**Digital (Iridesse) - 6x11 postcard example:**
- Click cost: $0.12/impression (CMYK, cover stock)
- Paper cost: $0.049/piece (100# gloss, with waste)
- **Printing subtotal:** $0.169/piece

**Offset - 6x11 postcard example (5,000+ quantity):**
- Makeready: $200 fixed cost
- Press time: 500 sheets/hour @ $175/hour = $0.35/sheet
- Paper cost: $0.034/sheet (8-up) = $0.00425/piece
- **Per-piece:** ($200 makeready ÷ 5,000 pcs) + ($0.35/8) + $0.00425 = $0.088/piece

**Add markup for printing:**
- Materials & production cost × 1.4-1.6 = retail price
- Industry standard: 40-60% markup over direct costs

**Example (digital, 6,033 pieces):**
- Production cost: $0.169/piece × 6,033 = $1,020
- Target pricing (50th percentile): $0.20/piece × 6,033 = **$1,207**
- Margin: ($1,207 - $1,020) / $1,207 = **15.5% gross margin**

### Step 3: Calculate Addressing Cost
**Inkjet addressing @ market rate:**
- **50th percentile:** $0.030/piece
- Cost basis: $0.015/piece (ink + labor)
- Margin: 50% gross

**Example (6,033 pieces):**
- Market rate: $0.030 × 6,033 = **$181**

### Step 4: Calculate Data Processing & Mail Prep
**CASS/Data Processing @ market rate:**
- **50th percentile:** $0.025/piece
- Cost basis: $0.012/piece (software + labor)

**Presort & Mail Prep @ market rate:**
- **50th percentile:** $0.065/piece
- Cost basis: $0.040/piece (labor at 300 pcs/hour, $25/hour rate)

**Combined services subtotal:**
- CASS: $0.025 × 6,033 = $151
- Presort/Mail Prep: $0.065 × 6,033 = $392
- **Services subtotal:** $151 + $392 = **$543**

**OR bundle as single line item:**
- "Data Processing & Mail Prep": $0.09/piece × 6,033 = **$543**

### Step 5: Calculate Postage (Pass-Through)
**First-Class presorted postcards:**
- Blended rate: $0.594/piece × 6,033 = **$3,582**
- **No markup** (industry standard pass-through)

### Step 6: Total Quote & Position in Market
**Market-rate quote (50th percentile):**
- Printing: $1,207 ($0.20/pc)
- Inkjet Addressing: $181 ($0.03/pc)
- Data Processing: $151 ($0.025/pc)
- Presort & Mail Prep: $392 ($0.065/pc)
- **Services Subtotal:** $1,931 ($0.32/pc)
- Postage: $3,582 ($0.594/pc)
- **TOTAL:** **$5,513** ($0.914/pc)

**Positioning options:**
- **WIN business (25th-40th percentile):** $0.85-$0.90/pc = $5,128-$5,430 total
- **Market-rate (50th percentile):** $0.91-$0.94/pc = $5,490-$5,671 total
- **Maximize margin (60th-70th percentile):** $0.95-$1.00/pc = $5,731-$6,033 total

---

## VOLUME BREAK ADJUSTMENTS

### Printing Cost Scaling

**Digital (Iridesse) - 6x11 Postcards:**

| Quantity | Per-Piece Printing Cost | Notes |
|----------|------------------------|-------|
| 100-500 | $0.22-$0.25/pc | Short-run premium, higher waste % |
| 500-2,500 | $0.18-$0.22/pc | Standard digital pricing |
| 2,500-5,000 | $0.16-$0.19/pc | Volume efficiency, lower waste |
| 5,000-10,000 | $0.14-$0.17/pc | Max digital efficiency |
| 10,000+ | Evaluate offset | Offset likely cheaper |

**Offset - 6x11 Postcards:**

| Quantity | Per-Piece Printing Cost | Notes |
|----------|------------------------|-------|
| 2,500-5,000 | $0.11-$0.14/pc | Makeready penalty still high |
| 5,000-10,000 | $0.08-$0.11/pc | Breakeven vs. digital |
| 10,000-25,000 | $0.06-$0.09/pc | Clear offset advantage |
| 25,000+ | $0.04-$0.07/pc | Maximum efficiency |

### Addressing & Mail Prep Scaling

**Inkjet addressing** scales modestly:
- Under 1,000: $0.035-$0.045/pc (setup penalty)
- 1,000-10,000: $0.025-$0.035/pc (standard rate)
- 10,000+: $0.020-$0.030/pc (volume discount)

**Data processing & mail prep** scales significantly:
- Under 1,000: $0.10-$0.15/pc (high labor ratio)
- 1,000-10,000: $0.08-$0.10/pc (efficient batching)
- 10,000+: $0.06-$0.08/pc (maximum efficiency)

### Market Positioning by Volume

**Small runs (under 2,500):**
- Digital is king; price aggressively to win
- Target 40th-60th percentile ($0.88-$0.94/pc range)
- Emphasize fast turnaround, personalization capabilities

**Medium runs (2,500-10,000):**
- Digital still competitive; evaluate offset case-by-case
- Target 50th-65th percentile ($0.88-$0.98/pc range)
- Highlight Iridesse specialty capabilities if relevant

**Long runs (10,000+):**
- Offset is typically required for competitiveness
- Target 50th-60th percentile (lower $/pc, volume discounts apply)
- Price aggressively to avoid losing to trade printers

---

## TURNAROUND TIME PRICING ADJUSTMENTS

**Standard turnaround (5-7 business days):**
- Base pricing as calculated above

**Rush turnaround (3-4 business days):**
- Add 15-25% to services subtotal
- Postage unchanged
- Typical market: +$0.05-$0.08/piece

**Super rush (1-2 business days):**
- Add 30-50% to services subtotal
- Postage unchanged (unless expedited shipping required)
- Typical market: +$0.10-$0.15/piece
- Justifies 75th-90th percentile positioning

---

## SPECIALTY PRICING - IRIDESSE CAPABILITIES

### Metallic Inks (Gold, Silver)
**Cost structure:**
- Additional click cost: +$0.03-$0.05/impression
- Design setup: $50-$100 (one-time for file prep)
- **Market pricing:** Add $0.08-$0.12/piece over standard CMYK

**Positioning:**
- Emphasize premium appearance, differentiates from competitors
- Justifies 75th-90th percentile overall pricing
- Target high-value campaigns (real estate, luxury goods, events)

### Clear Coating (Spot UV Effect)
**Cost structure:**
- Additional click cost: +$0.03-$0.04/impression
- Design setup: $50-$100
- **Market pricing:** Add $0.06-$0.10/piece

### White Ink (for dark substrates)
**Cost structure:**
- Additional click cost: +$0.04-$0.06/impression
- Substrate premium (dark stocks): +$0.02-$0.05/piece
- **Market pricing:** Add $0.10-$0.15/piece

**When to upsell:**
- Client shows interest in "standing out" or "premium look"
- Budget allows for 75th+ percentile pricing
- High-value audience justifies premium execution

---

## FORMULA SUMMARY FOR QUICK QUOTING

### 6x11 Postcard Formula (Digital, 50th Percentile Market Rate)

**Printing:**
- Base: $0.20/piece
- Adjust for volume: ±$0.02-$0.05/piece
- Adjust for specialty: +$0.08-$0.15/piece (metallic, clear, white)

**Addressing:**
- Base: $0.030/piece
- Adjust for volume: ±$0.005-$0.010/piece

**Data & Mail Prep:**
- Base: $0.090/piece (bundled)
- OR itemize: CASS $0.025/pc + Presort $0.065/pc
- Adjust for volume: ±$0.01-$0.02/piece

**Services Subtotal:**
- **Median:** $0.32/piece
- Range: $0.27-$0.37/piece depending on volume and specs

**Postage (First-Class presorted):**
- Postcards: $0.594/piece (pass-through)
- Letters: $0.573/piece (pass-through)

**TOTAL ALL-IN:**
- **Median (50th percentile):** $0.914/piece
- 25th percentile (win business): $0.85/piece
- 75th percentile (maximize margin): $0.98/piece

### Quick Positioning Decision Tree

**When client asks for quote:**

1. **Get specs:** quantity, size, color, stock, turnaround
2. **Calculate base production cost** (equipment selection, clicks, paper)
3. **Apply market rate markup** to hit target percentile
4. **Add addressing at market rate** ($0.030/pc typical)
5. **Add data/mail prep at market rate** ($0.09/pc bundled typical)
6. **Add postage pass-through** (no markup)
7. **Position based on client signals:**
   - Price-sensitive, shopping around → 30th-40th percentile
   - Professional buyer, expects fair market → 50th percentile
   - Values service, fast turn, consultation → 60th-75th percentile
   - Rush job, specialty requirements → 75th-90th percentile

---

## COMPETITIVE INTELLIGENCE - WHEN TO MATCH/BEAT

### Franchise Shops (Allegra, Minuteman, Sir Speedy, AlphaGraphics)
**Typical pricing:** 75th-80th percentile ($0.95-$1.05/pc for standard postcards)

**When to undercut:**
- Client is price-shopping and mentions franchise quote
- Standard job with no specialty requirements
- Target: Beat them by 5-10% to win business

**When NOT to undercut:**
- Client values franchise brand, relationship, convenience
- You can offer specialty capabilities (Iridesse effects) they can't match
- Rush job where your speed/service justifies premium

### Independent Mail Houses
**Typical pricing:** 45th-55th percentile ($0.88-$0.94/pc)

**When to match:**
- Professional buyer comparing multiple quotes
- Standard specifications, they're your true competition
- Target: Match within $0.02/piece, differentiate on service/turn time

**When to beat:**
- New client acquisition, worth thin margin to win first job
- Target: Undercut by 5-8% to establish relationship

### Online/Trade Printers (48HourPrint, PSI Mail, Modern Postcard)
**Typical pricing:** 20th-30th percentile ($0.77-$0.85/pc)

**When to match:**
- HIGH RISK - these are loss leaders or out-of-state volume players
- Only match if: (a) huge volume justifies thin margin, OR (b) client demands local provider

**When NOT to match:**
- You cannot profitably hit their pricing on typical volumes
- Emphasize: local service, faster turn, personal attention, no two-vendor coordination
- Let them win on price; you win on value and service

### When Client Says "I Got a Quote for $X"

**Response framework:**
1. "I appreciate you sharing that. Can I ask—was that an all-in quote including postage, or just the printing and mailing services?"
2. "What was the turnaround time they quoted?"
3. "Were there any specialty requirements or was it straightforward CMYK on standard stock?"

**Then:**
- If their quote is 25th percentile (online): "That's a trade printer price. We're local, faster turn, and you get personalized service. Our quote is $X, which includes [value-adds]."
- If their quote is 50th percentile (mail house): "That's right in line with market rate. We can match that at $X and offer [differentiation]."
- If their quote is 75th percentile (franchise): "I can beat that. I'll quote you $X, which gives you the same quality and service at a better value."

---

## OUTPUT FORMAT FOR QUOTES

### Format 1: Simple (Most Common for Clients)
```
6,033 Postcards - 6x11, 4/4 Full Color, 100# Gloss Cover
First-Class Presorted Mail

Print & Prepare Mail:        $1,931    ($0.32/pc)
Postage:                     $3,582    ($0.594/pc)
                             ------
TOTAL:                       $5,513    ($0.914/pc)

Turnaround: 5-7 business days
```

### Format 2: Itemized (Mail Houses, Professional Buyers)
```
6,033 Postcards - 6x11, 4/4 Full Color, 100# Gloss Cover
First-Class Presorted Automation

Printing:                    $1,207    ($0.20/pc)
Inkjet Addressing:           $  181    ($0.03/pc)
Data Processing (CASS):      $  151    ($0.025/pc)
Presort & Mail Prep:         $  392    ($0.065/pc)
                             ------
Subtotal - Services:         $1,931    ($0.32/pc)
Postage:                     $3,582    ($0.594/pc)
                             ------
TOTAL:                       $5,513    ($0.914/pc)

Turnaround: 5-7 business days
```

### Format 3: Ultra-Simple (Franchise Style)
```
6,033 Postcards - 6x11, 4/4 Full Color, 100# Gloss
Printing, Addressing, CASS, Presort, First-Class Mail

All-In Price:                $5,800    ($0.96/pc)

Turnaround: 5 business days
```

---

## CRITICAL ACCURACY REQUIREMENTS

### Always Include in Response:
1. **Per-piece AND total pricing** (clients think both ways)
2. **Itemized breakdown** OR bundled (match client sophistication)
3. **Postage separately stated** (transparency on pass-through vs. markup)
4. **Turnaround time** (affects pricing tier)
5. **Percentile positioning** (so user understands competitiveness)

### Always Clarify Before Quoting:
1. **Quantity** (volume dramatically affects per-piece economics)
2. **Size** (6x11 vs 6x9 vs 8.5x11 affects paper yield, postage class)
3. **Printing specs** (4/4, 4/1, 4/0 affects click costs)
4. **Paper stock** (weight and finish affect material costs, postage)
5. **Turnaround** (rush affects pricing tier)
6. **Mail class** (First-Class vs Marketing Mail affects postage significantly)

### Validation Checks Before Finalizing Quote:
- [ ] **Printing cost** is within $0.15-$0.25/piece for standard digital postcards
- [ ] **Addressing cost** is within $0.025-$0.035/piece
- [ ] **Data/mail prep cost** is within $0.08-$0.12/piece
- [ ] **Services subtotal** is within $0.27-$0.37/piece (50th percentile range)
- [ ] **Postage** matches current USPS rates (no markup unless explicitly stated)
- [ ] **Total all-in price** falls within target percentile range (25th-90th)
- [ ] **Margin** on services is 35-60% gross (sustainable for business)

---

## EXAMPLES - WORKED QUOTES

### Example 1: Standard 6x11 Postcard, Market-Rate Quote

**Specs:**
- 6,033 pieces
- 6x11 finished size
- 4/4 full color
- 100# gloss cover stock
- First-Class presorted mail
- Standard turnaround (5-7 days)

**Production Plan:**
- **Equipment:** Xerox Iridesse (digital, quantity under 10,000)
- **Workflow:** Print on Iridesse → offline cutting to size → inkjet addressing → data processing/CASS → presort/bundle → USPS drop

**Cost Calculation:**
- **Printing production cost:** $0.12 click + $0.049 paper = $0.169/piece × 6,033 = $1,020
- **Printing market rate (50th percentile):** $0.20/piece × 6,033 = $1,207 (18.3% margin)
- **Addressing market rate:** $0.030/piece × 6,033 = $181
- **CASS processing market rate:** $0.025/piece × 6,033 = $151
- **Presort & mail prep market rate:** $0.065/piece × 6,033 = $392
- **Services subtotal:** $1,931 ($0.32/piece)
- **Postage (First-Class presorted, blended):** $0.594/piece × 6,033 = $3,582
- **TOTAL:** $5,513 ($0.914/piece)

**Positioning:** 50th percentile - market-competitive, defendable, profitable

**Quote to client:**
```
6,033 Postcards - 6x11, 4/4 Full Color, 100# Gloss Cover
First-Class Presorted Mail

Print & Prepare Mail:        $1,931    ($0.32/pc)
Postage:                     $3,582    ($0.594/pc)
                             ------
TOTAL:                       $5,513    ($0.914/pc)

Turnaround: 5-7 business days
```

---

### Example 2: Win Business Quote (Undercutting Franchise)

**Client says:** "I got a quote from Allegra for $5,800."

**Response strategy:** Undercut by ~7% to win business, position at 40th percentile

**Same specs as Example 1**

**Adjusted Pricing:**
- Printing: $1,150 ($0.19/pc) - reduced margin
- Addressing: $181 ($0.03/pc) - hold
- Data/Mail Prep: $489 ($0.081/pc) - bundled, slight reduction
- **Services subtotal:** $1,820 ($0.30/pc)
- Postage: $3,582 ($0.594/pc) - no change
- **TOTAL:** $5,402 ($0.895/pc)

**Positioning:** 42nd percentile - below market median, competitive win

**Quote to client:**
```
6,033 Postcards - 6x11, 4/4 Full Color, 100# Gloss Cover
First-Class Presorted Mail

Print & Prepare Mail:        $1,820    ($0.30/pc)
Postage:                     $3,582    ($0.594/pc)
                             ------
TOTAL:                       $5,402    ($0.895/pc)

Turnaround: 5-7 business days

[Note to client: "I can beat that franchise quote and still deliver the same quality with faster turnaround. You're local to us, so we can also handle any last-minute changes more easily."]
```

---

### Example 3: Premium Quote with Iridesse Specialty

**Specs:**
- 6,033 pieces
- 6x11 finished size
- 4/4 full color + SPOT GOLD metallic accent
- 100# gloss cover stock
- First-Class presorted mail
- Standard turnaround (5-7 days)

**Production Plan:**
- **Equipment:** Xerox Iridesse with gold metallic (6-color capability)
- **Workflow:** Print on Iridesse with gold → offline cutting → addressing → processing → presort → mail

**Cost Calculation:**
- **Printing production cost:** $0.12 CMYK click + $0.04 gold click + $0.049 paper = $0.209/piece
- **Design setup (gold file prep):** $75 one-time
- **Printing market rate (premium positioning):** $0.28/piece × 6,033 = $1,689 (includes gold upcharge + premium margin)
- **Addressing:** $0.030/piece × 6,033 = $181
- **Data/Mail Prep:** $0.09/piece × 6,033 = $543
- **Services subtotal:** $2,413 ($0.40/piece)
- **Postage:** $3,582 ($0.594/pc)
- **TOTAL:** $5,995 ($0.994/piece)

**Positioning:** 70th percentile - premium product justifies premium price

**Quote to client:**
```
6,033 Postcards - 6x11, 4/4 Full Color + GOLD METALLIC Accent
100# Gloss Cover, First-Class Presorted Mail

Print & Prepare Mail:        $2,413    ($0.40/pc)
  (includes specialty gold metallic ink)
Postage:                     $3,582    ($0.594/pc)
                             ------
TOTAL:                       $5,995    ($0.994/pc)

Turnaround: 5-7 business days

[Note to client: "The gold metallic really makes these pop—it's a premium feature that your recipients will notice immediately. Most competitors can't offer this capability."]
```

---

## SKILL USAGE INSTRUCTIONS FOR CLAUDE

When user requests direct mail pricing:

1. **Clarify specifications** using the checklist in "Critical Accuracy Requirements"
2. **Select equipment** based on quantity, specs, turnaround (decision tree in pricing methodology)
3. **Calculate costs** using formulas and market data tables
4. **Position strategically** based on competitive context (percentile targeting)
5. **Format quote** using appropriate output format (simple vs. itemized)
6. **Explain value** in plain English - why this price, what drives cost, how to optimize

**Tone:** Confident, direct, consultative. You're Marcus Keating with 30 years of experience. You know this market cold. You provide transparent breakdowns and educate clients on value drivers.

**Accuracy standard:** Quotes must be within ±5% of actual Central Florida market rates. Cross-check against competitor data tables before finalizing.

---

## QUICK REFERENCE - KEY Numbers to Memorize

**6x11 Postcard (4/4, 100# gloss, First-Class presorted):**
- **Printing only:** $0.20/pc (50th percentile)
- **Services subtotal:** $0.32/pc (printing + addressing + data/mail prep)
- **First-Class postage:** $0.594/pc (pass-through)
- **Total all-in:** $0.914/pc (50th percentile market rate)

**Percentile ranges (total all-in):**
- 25th: $0.85/pc (win business)
- 50th: $0.91/pc (market rate)
- 75th: $0.98/pc (premium)

**Equipment breakeven (6x11 postcards):**
- Under 5,000: Digital (Iridesse)
- 5,000-7,500: Evaluate case-by-case
- Over 7,500: Offset

**Iridesse specialty upcharges:**
- Gold/Silver metallic: +$0.08-$0.12/pc
- Clear coating: +$0.06-$0.10/pc
- White ink: +$0.10-$0.15/pc

---

**END OF SKILL**
